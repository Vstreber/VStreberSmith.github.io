<html>
    <head>
        <link rel="stylesheet" href="../css/hwk8.css">
    </head>
    <body>

    <form action="verify.html.php" method="POST">
        Username: <input type="text" name="username"><br>
        Password: <input type="text" name="password"><br>
        <input type="submit" >
    </form>
    
    </body>
</html>